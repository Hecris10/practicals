TypeScript Practical Tests

```
$ npm install
$ npm test
```