import { HairColor, Person } from "./models";

export function namesOfAncestors(p: Person): string[] {
    return [];
}

export function mostCommonHairColorOfAncestors(p: Person): HairColor {
    return HairColor.BLACK;
}
